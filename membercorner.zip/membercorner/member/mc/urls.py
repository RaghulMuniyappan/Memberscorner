from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
  path('',views.index,name="index"),
  path('abi',views.abinesh,name="abi"),
  path('login',views.login,name="login"),
  path('payment',views.payment,name="payment"),
  path('payments',views.payments,name="payments"),
  path('paymentu',views.paymentu,name="paymentu"),
  path('paym',views.paym,name="paym")

]