from django.shortcuts import render
from django.http import HttpResponse
from . models import *

def index(request):
    return render(request,'index.html')

def abinesh(request):
    return render(request,'abi.html')

def login(request):
    return render(request,'login.html')

def payment(request):
    return render(request,'payment.html')

def payments(request):
    return render(request,'payment.html')


def paymentu(request):
    return render(request,'payment.html')

def paym(request):
    name1=request.POST['firstname']
    email1=request.POST['email']
    address1=request.POST['address']
    city1=request.POST['city']
    state1=request.POST['state']
    zip1=request.POST['zip']
    cardname1=request.POST['cardname']
    cardnumber1=request.POST['cardnumber']
    expmonth1=request.POST['expmonth']
    expyear1=request.POST['expyear']
    cvv1=request.POST['cvv']
    row=pay.objects.create(name=name1,email=email1,address=address1,city=city1,state=state1,zip=zip1,nameoncard=cardname1,creditcardnumber=cardnumber1,exp_month=expmonth1,exp_year=expyear1,cvv=cvv1)
    row.save()
    return HttpResponse("Success")


# Create your views here.